export const SAVE_KEY = 'bottle_flip_save_v1'
export const MAX_LVL = 10

export const UPGRADES = [
  {
    id: 'water',
    name: 'уровень воды',
    desc: '+3% шанс встать',
    baseCost: 25,
    mult: 1.45
  },
  {
    id: 'control',
    name: 'крутка',
    desc: '+1.5% шанс x2',
    baseCost: 30,
    mult: 1.45
  },
  {
    id: 'greed',
    name: 'жадность',
    desc: 'больше монет',
    baseCost: 20,
    mult: 1.5
  },
  {
    id: 'luck',
    name: 'везунчик',
    desc: '+2% второй шанс',
    baseCost: 40,
    mult: 1.5
  }
]

export const BOTTLES = [
  {
    id: 'plastic',
    name: 'пластик',
    desc: 'базовый рандом',
    price: 0,
    coinMult: 1.0,
    chanceBonus: 0,
    goldBonus: 0
  },
  {
    id: 'shaker',
    name: 'шейкер',
    desc: '+15% монет',
    price: 150,
    coinMult: 1.15,
    chanceBonus: 0,
    goldBonus: 0
  },
  {
    id: 'flask',
    name: 'колба',
    desc: '+8% шанс',
    price: 400,
    coinMult: 1.0,
    chanceBonus: 8,
    goldBonus: 0
  },
  {
    id: 'thermos',
    name: 'термос',
    desc: '+25% м., +4% ш.',
    price: 900,
    coinMult: 1.25,
    chanceBonus: 4,
    goldBonus: 0
  },
  {
    id: 'gold',
    name: 'золото',
    desc: '+50% м., +5% x2',
    price: 2500,
    coinMult: 1.5,
    chanceBonus: 0,
    goldBonus: 5
  }
]

export function getDefaultState() {
  return {
    coins: 0,
    best: 0,
    streak: 0,
    flips: 0,
    upg: {
      water: 0,
      control: 0,
      greed: 0,
      luck: 0
    },
    owned: ['plastic'],
    equipped: 'plastic'
  }
}

export function parseSave(raw) {
  var def = getDefaultState()
  if (!raw) return def
  try {
    var d = JSON.parse(raw)
    if (!d || typeof d !== 'object') return def
    var state = {
      coins: typeof d.coins === 'number' ? d.coins : 0,
      best: typeof d.best === 'number' ? d.best : 0,
      streak: typeof d.streak === 'number' ? d.streak : 0,
      flips: typeof d.flips === 'number' ? d.flips : 0,
      upg: {
        water: d.upg && typeof d.upg.water === 'number' ? d.upg.water : 0,
        control: d.upg && typeof d.upg.control === 'number' ? d.upg.control : 0,
        greed: d.upg && typeof d.upg.greed === 'number' ? d.upg.greed : 0,
        luck: d.upg && typeof d.upg.luck === 'number' ? d.upg.luck : 0
      },
      owned: Array.isArray(d.owned) && d.owned.length > 0 ? d.owned : ['plastic'],
      equipped: typeof d.equipped === 'string' ? d.equipped : 'plastic'
    }
    if (state.owned.indexOf('plastic') === -1) {
      state.owned.push('plastic')
    }
    if (state.owned.indexOf(state.equipped) === -1) {
      state.equipped = 'plastic'
    }
    return state
  } catch (e) {
    return def
  }
}

export function getBottleById(id) {
  for (var i = 0; i < BOTTLES.length; i++) {
    if (BOTTLES[i].id === id) return BOTTLES[i]
  }
  return BOTTLES[0]
}

export function getUpgradeCost(upgDef, level) {
  return Math.floor(upgDef.baseCost * Math.pow(upgDef.mult, level))
}

export function getBottleImg(bottleId, frameIdx) {
  var f = ((frameIdx % 8) + 8) % 8
  return '/common/bottles/' + bottleId + '_' + f + '.png'
}
