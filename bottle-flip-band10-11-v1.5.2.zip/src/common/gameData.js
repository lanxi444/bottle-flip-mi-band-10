export const SAVE_KEY = 'bottle_flip_save_v1'
export const MAX_LVL = 15

export const UPGRADES = [
  { id: 'water', name: 'уровень', desc: '+2% шанс встать', baseCost: 25, mult: 1.42 },
  { id: 'control', name: 'крутка', desc: '+1.2% шанс x2', baseCost: 30, mult: 1.42 },
  { id: 'greed', name: 'жадность', desc: '+6 базовых монет', baseCost: 20, mult: 1.45 },
  { id: 'luck', name: 'везунчик', desc: '+2% второй шанс', baseCost: 40, mult: 1.45 },
  { id: 'charge', name: 'хватка', desc: 'жирнее зажатие', baseCost: 50, mult: 1.48 },
  { id: 'events', name: 'аномалия', desc: 'чаще модификатор', baseCost: 60, mult: 1.5 },
  { id: 'acrobat', name: 'акробат', desc: 'сальто в воздухе', baseCost: 45, mult: 1.48 }
]

export const BOTTLES = [
  { id: 'plastic', name: 'пластик', desc: 'базовый рандом', price: 0, coinMult: 1.0, chanceBonus: 0, goldBonus: 0, flipBonus: 0 },
  { id: 'shaker', name: 'шейкер', desc: '+15% монет', price: 150, coinMult: 1.15, chanceBonus: 0, goldBonus: 0, flipBonus: 0 },
  { id: 'flask', name: 'колба', desc: '+8% шанс', price: 400, coinMult: 1.0, chanceBonus: 8, goldBonus: 0, flipBonus: 0 },
  { id: 'thermos', name: 'термос', desc: '+25% м., +4% ш.', price: 900, coinMult: 1.25, chanceBonus: 4, goldBonus: 0, flipBonus: 0 },
  { id: 'mug', name: 'кружка', desc: '+35% м., +4% x2', price: 1400, coinMult: 1.35, chanceBonus: 0, goldBonus: 4, flipBonus: 0 },
  { id: 'canister', name: 'канистра', desc: '+50% м., -4% ш.', price: 2200, coinMult: 1.5, chanceBonus: -4, goldBonus: 2, flipBonus: 0 },
  { id: 'gold', name: 'золото', desc: '+65% м., +6% x2', price: 3500, coinMult: 1.65, chanceBonus: 0, goldBonus: 6, flipBonus: 0 },
  { id: 'banana', name: 'банан', desc: '+85% м., -6% ш.', price: 5000, coinMult: 1.85, chanceBonus: -6, goldBonus: 5, flipBonus: 0 },
  { id: 'brick', name: 'кирпич', desc: 'x2.5 м., -10% ш.', price: 7000, coinMult: 2.5, chanceBonus: -10, goldBonus: 3, flipBonus: 0 },
  { id: 'chips', name: 'тубус', desc: 'x2.7 м., +1 сальто', price: 8500, coinMult: 2.7, chanceBonus: -5, goldBonus: 4, flipBonus: 1 },
  { id: 'cactus', name: 'кактус', desc: 'x2.1 м., +7% x2', price: 10000, coinMult: 2.1, chanceBonus: -3, goldBonus: 7, flipBonus: 0 },
  { id: 'butter', name: 'бутерброд', desc: 'x2.9 м., масло!', price: 12000, coinMult: 2.9, chanceBonus: -8, goldBonus: 5, flipBonus: 0 },
  { id: 'dumbbell', name: 'гантеля', desc: 'x3.0 м., -12% ш.', price: 15000, coinMult: 3.0, chanceBonus: -12, goldBonus: 4, flipBonus: 0 },
  { id: 'brickphone', name: 'кирпичфон', desc: 'x3.3 м., бьет стол', price: 18000, coinMult: 3.3, chanceBonus: -7, goldBonus: 6, flipBonus: 0 },
  { id: 'plunger', name: 'вантуз', desc: 'x3.2 м., +10% ш.', price: 22000, coinMult: 3.2, chanceBonus: 10, goldBonus: 3, flipBonus: 0 },
  { id: 'trophy', name: 'кубок', desc: 'x4.0 м., +10% x2', price: 28000, coinMult: 4.0, chanceBonus: 0, goldBonus: 10, flipBonus: 0 },
  { id: 'kettlebell', name: 'гиря 16кг', desc: 'x4.8 м., -14% ш.', price: 38000, coinMult: 4.8, chanceBonus: -14, goldBonus: 8, flipBonus: 0 }
]

export const TABLES = [
  { id: 'wood', name: 'дерево', desc: 'классика, +0%', price: 0, coinBonus: 0 },
  { id: 'desk', name: 'парта', desc: 'школьная, +5% м.', price: 200, coinBonus: 0.05 },
  { id: 'concrete', name: 'бетон', desc: 'плита, +10% м.', price: 500, coinBonus: 0.1 },
  { id: 'hood', name: 'капот', desc: 'тачка, +15% м.', price: 1000, coinBonus: 0.15 },
  { id: 'neon', name: 'неон', desc: 'кибер, +20% м.', price: 1800, coinBonus: 0.2 },
  { id: 'vip', name: 'мрамор', desc: 'люкс, +30% м.', price: 3500, coinBonus: 0.3 },
  { id: 'lava', name: 'лава', desc: 'вулкан, +40% м.', price: 5500, coinBonus: 0.4 },
  { id: 'ice', name: 'лед', desc: 'каток, +50% м.', price: 8500, coinBonus: 0.5 },
  { id: 'space', name: 'космос', desc: 'орбита, +65% м.', price: 13000, coinBonus: 0.65 },
  { id: 'matrix', name: 'матрица', desc: 'код, +85% м.', price: 20000, coinBonus: 0.85 }
]

export const MODIFIERS = [
  { id: 'none', label: '', cls: 'mod-none', chanceDelta: 0, coinMult: 1.0, streakAdd: 1 },
  { id: 'gold_rush', label: 'золотой x2.5', cls: 'mod-gold', chanceDelta: 0, coinMult: 2.5, streakAdd: 1 },
  { id: 'wind', label: 'ветер +15% ш.', cls: 'mod-wind', chanceDelta: 15, coinMult: 1.0, streakAdd: 1 },
  { id: 'storm', label: 'шторм -10% x3.5', cls: 'mod-storm', chanceDelta: -10, coinMult: 3.5, streakAdd: 1 },
  { id: 'hot', label: 'жара +2 сер. x1.5', cls: 'mod-hot', chanceDelta: 0, coinMult: 1.5, streakAdd: 2 },
  { id: 'quake', label: 'землетряс! x4', cls: 'mod-quake', chanceDelta: -5, coinMult: 4.0, streakAdd: 1 }
]

export const ACHIEVEMENTS = [
  { id: 'flips_50', title: 'новичок', desc: '50 бросков', reward: 150, check: function (st) { return st.flips >= 50 } },
  { id: 'streak_5', title: 'снайпер', desc: 'серия 5 подряд', reward: 350, check: function (st) { return st.best >= 5 } },
  { id: 'gold_5', title: 'ювелир', desc: '5 золотых x2', reward: 500, check: function (st) { return st.goldWins >= 5 } },
  { id: 'items_5', title: 'барахольщик', desc: 'купить 5 вещей', reward: 800, check: function (st) { return st.owned.length >= 5 } },
  { id: 'air_4', title: 'акробат', desc: '4+ сальто за раз', reward: 1500, check: function (st) { return st.maxAirFlips >= 4 } },
  { id: 'streak_10', title: 'псих рандома', desc: 'серия 10 подряд', reward: 2000, check: function (st) { return st.best >= 10 } },
  { id: 'flips_500', title: 'маньяк', desc: '500 бросков', reward: 2500, check: function (st) { return st.flips >= 500 } },
  { id: 'brick_own', title: 'строитель', desc: 'купить кирпич', reward: 3000, check: function (st) { return st.owned.indexOf('brick') !== -1 } },
  { id: 'chips_own', title: 'хруст', desc: 'купить тубус', reward: 4000, check: function (st) { return st.owned.indexOf('chips') !== -1 } },
  { id: 'trophy_own', title: 'чемпион', desc: 'купить кубок', reward: 10000, check: function (st) { return st.owned.indexOf('trophy') !== -1 } }
]

export function getDefaultState() {
  return {
    coins: 0,
    best: 0,
    streak: 0,
    flips: 0,
    wins: 0,
    goldWins: 0,
    luckWins: 0,
    totalCoins: 0,
    maxReward: 0,
    maxAirFlips: 1,
    casinoWins: 0,
    freeSpins: 0,
    freeSpinBet: 100,
    forceMod: '',
    vibeOn: true,
    godMode: false,
    prestige: 0,
    claimedAch: [],
    upg: { water: 0, control: 0, greed: 0, luck: 0, charge: 0, events: 0, acrobat: 0 },
    owned: ['plastic'],
    equipped: 'plastic',
    ownedTables: ['wood'],
    equippedTable: 'wood'
  }
}

export function parseSave(raw) {
  var def = getDefaultState()
  if (!raw) return def
  try {
    var d = JSON.parse(raw)
    if (!d || typeof d !== 'object') return def
    var state = {
      coins: typeof d.coins === 'number' ? d.coins : 0,
      best: typeof d.best === 'number' ? d.best : 0,
      streak: typeof d.streak === 'number' ? d.streak : 0,
      flips: typeof d.flips === 'number' ? d.flips : 0,
      wins: typeof d.wins === 'number' ? d.wins : 0,
      goldWins: typeof d.goldWins === 'number' ? d.goldWins : 0,
      luckWins: typeof d.luckWins === 'number' ? d.luckWins : 0,
      totalCoins: typeof d.totalCoins === 'number' ? d.totalCoins : (typeof d.coins === 'number' ? d.coins : 0),
      maxReward: typeof d.maxReward === 'number' ? d.maxReward : 0,
      maxAirFlips: typeof d.maxAirFlips === 'number' ? d.maxAirFlips : 1,
      casinoWins: typeof d.casinoWins === 'number' ? d.casinoWins : 0,
      freeSpins: typeof d.freeSpins === 'number' ? d.freeSpins : 0,
      freeSpinBet: typeof d.freeSpinBet === 'number' && d.freeSpinBet > 0 ? d.freeSpinBet : 100,
      forceMod: typeof d.forceMod === 'string' ? d.forceMod : '',
      vibeOn: typeof d.vibeOn === 'boolean' ? d.vibeOn : true,
      godMode: typeof d.godMode === 'boolean' ? d.godMode : false,
      prestige: typeof d.prestige === 'number' ? d.prestige : 0,
      claimedAch: Array.isArray(d.claimedAch) ? d.claimedAch : [],
      upg: {
        water: d.upg && typeof d.upg.water === 'number' ? d.upg.water : 0,
        control: d.upg && typeof d.upg.control === 'number' ? d.upg.control : 0,
        greed: d.upg && typeof d.upg.greed === 'number' ? d.upg.greed : 0,
        luck: d.upg && typeof d.upg.luck === 'number' ? d.upg.luck : 0,
        charge: d.upg && typeof d.upg.charge === 'number' ? d.upg.charge : 0,
        events: d.upg && typeof d.upg.events === 'number' ? d.upg.events : 0,
        acrobat: d.upg && typeof d.upg.acrobat === 'number' ? d.upg.acrobat : 0
      },
      owned: Array.isArray(d.owned) && d.owned.length > 0 ? d.owned : ['plastic'],
      equipped: typeof d.equipped === 'string' ? d.equipped : 'plastic',
      ownedTables: Array.isArray(d.ownedTables) && d.ownedTables.length > 0 ? d.ownedTables : ['wood'],
      equippedTable: typeof d.equippedTable === 'string' ? d.equippedTable : 'wood'
    }
    if (state.owned.indexOf('plastic') === -1) state.owned.push('plastic')
    if (state.owned.indexOf(state.equipped) === -1) state.equipped = 'plastic'
    if (state.ownedTables.indexOf('wood') === -1) state.ownedTables.push('wood')
    if (state.ownedTables.indexOf(state.equippedTable) === -1) state.equippedTable = 'wood'
    return state
  } catch (e) {
    return def
  }
}

export function buildSavePayload(st) {
  return JSON.stringify({
    coins: st.coins,
    best: st.best,
    streak: st.streak,
    flips: st.flips,
    wins: st.wins,
    goldWins: st.goldWins,
    luckWins: st.luckWins,
    totalCoins: st.totalCoins,
    maxReward: st.maxReward,
    maxAirFlips: st.maxAirFlips,
    casinoWins: st.casinoWins,
    freeSpins: st.freeSpins,
    freeSpinBet: st.freeSpinBet,
    forceMod: st.forceMod,
    vibeOn: st.vibeOn,
    godMode: st.godMode,
    prestige: st.prestige,
    claimedAch: st.claimedAch,
    upg: st.upg,
    owned: st.owned,
    equipped: st.equipped,
    ownedTables: st.ownedTables,
    equippedTable: st.equippedTable
  })
}

export function getBottleById(id) {
  for (var i = 0; i < BOTTLES.length; i++) {
    if (BOTTLES[i].id === id) return BOTTLES[i]
  }
  return BOTTLES[0]
}

export function getTableById(id) {
  for (var i = 0; i < TABLES.length; i++) {
    if (TABLES[i].id === id) return TABLES[i]
  }
  return TABLES[0]
}

export function getModifierById(id) {
  for (var i = 0; i < MODIFIERS.length; i++) {
    if (MODIFIERS[i].id === id) return MODIFIERS[i]
  }
  return MODIFIERS[0]
}

export function getUpgradeCost(upgDef, level) {
  return Math.floor(upgDef.baseCost * Math.pow(upgDef.mult, level))
}

export function getBottleImg(bottleId, frameIdx) {
  var f = ((frameIdx % 4) + 4) % 4
  return '/common/bottles/' + bottleId + '_' + f + '.png'
}

export function rollModifier(eventsLvl) {
  var triggerChance = 22 + eventsLvl * 3
  if (triggerChance > 72) triggerChance = 72
  if (Math.random() * 100 >= triggerChance) {
    return MODIFIERS[0]
  }
  var pick = 1 + Math.floor(Math.random() * (MODIFIERS.length - 1))
  return MODIFIERS[pick]
}
